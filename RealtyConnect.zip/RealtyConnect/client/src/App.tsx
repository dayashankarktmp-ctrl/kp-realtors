import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Home from "@/pages/Home";
import Properties from "@/pages/Properties";
import Rent from "@/pages/Rent";
import PropertyDetail from "@/pages/PropertyDetail";
import Packages from "@/pages/Packages";
import About from "@/pages/About";
import AgentSignup from "@/pages/AgentSignup";
import UserRegister from "@/pages/UserRegister";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/properties" component={Properties} />
      <Route path="/rent" component={Rent} />
      <Route path="/property/:id" component={PropertyDetail} />
      <Route path="/packages" component={Packages} />
      <Route path="/about" component={About} />
      <Route path="/agent-signup" component={AgentSignup} />
      <Route path="/register" component={UserRegister} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
