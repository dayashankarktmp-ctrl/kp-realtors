import Hero from "@/components/Hero";
import PropertyCard from "@/components/PropertyCard";
import PackageCard from "@/components/PackageCard";
import TestimonialCard from "@/components/TestimonialCard";
import HowItWorks from "@/components/HowItWorks";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Search, MapPin, FileText, PartyPopper, Building2, Users, DollarSign, Clock } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";

import heroImage from "@assets/stock_images/modern_luxury_apartm_0405f809.jpg";
import property1 from "@assets/stock_images/luxury_3_bedroom_apa_8b57e0b2.jpg";
import property2 from "@assets/stock_images/modern_villa_house_e_58316048.jpg";
import property3 from "@assets/stock_images/contemporary_office__99483289.jpg";
import property4 from "@assets/stock_images/budget_apartment_bed_027a5ce7.jpg";
import property5 from "@assets/stock_images/agricultural_farmlan_f1d67d02.jpg";
import property6 from "@assets/stock_images/independent_house_re_a0b54a30.jpg";
import testimonial1 from "@assets/stock_images/professional_real_es_7e21f9ed.jpg";
import testimonial2 from "@assets/stock_images/professional_real_es_34a6b1c9.jpg";
import testimonial3 from "@assets/stock_images/professional_real_es_5e9d40b2.jpg";

export default function Home() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const featuredProperties = [
    {
      id: "1",
      image: property1,
      title: "Luxury 3BHK Apartment",
      type: "Apartment",
      location: "Sector 45, Gurgaon",
      price: "₹85,50,000",
      pricePerSqft: "₹7,500",
      beds: 3,
      baths: 2,
      sqft: 1140,
      featured: true,
    },
    {
      id: "2",
      image: property2,
      title: "Modern 4BHK Villa",
      type: "Villa",
      location: "DLF Phase 5, Gurgaon",
      price: "₹2.5 Cr",
      pricePerSqft: "₹12,000",
      beds: 4,
      baths: 3,
      sqft: 2080,
      featured: true,
      urgent: true,
    },
    {
      id: "3",
      image: property3,
      title: "Premium Office Space",
      type: "Commercial Shop",
      location: "Cyber City, Gurgaon",
      price: "₹1.2 Cr",
      pricePerSqft: "₹8,500",
      beds: 0,
      baths: 2,
      sqft: 1411,
      featured: true,
    },
    {
      id: "4",
      image: property4,
      title: "2BHK Budget Apartment",
      type: "Apartment",
      location: "Sohna Road, Gurgaon",
      price: "₹45,00,000",
      pricePerSqft: "₹6,200",
      beds: 2,
      baths: 2,
      sqft: 725,
      featured: true,
      urgent: true,
    },
    {
      id: "5",
      image: property5,
      title: "Agriculture Land",
      type: "Agriculture Land",
      location: "Outskirts, Gurgaon",
      price: "₹75,00,000",
      pricePerSqft: "₹1,500",
      beds: 0,
      baths: 0,
      sqft: 5000,
      featured: true,
    },
    {
      id: "6",
      image: property6,
      title: "Independent House",
      type: "Independent House",
      location: "MG Road, Gurgaon",
      price: "₹3.2 Cr",
      pricePerSqft: "₹15,000",
      beds: 5,
      baths: 4,
      sqft: 2133,
      featured: true,
      urgent: true,
    },
  ];

  const packages = [
    {
      name: "STARTER PACKAGE",
      price: "₹99",
      originalPrice: "₹199",
      description: "Perfect for individual property sellers",
      features: [
        { name: "Property Submissions", included: true, value: "10" },
        { name: "Basic Amenities Setup", included: true },
        { name: "Image Gallery", included: true, value: "10 photos" },
        { name: "Listing Validity", included: true, value: "30 Days" },
        { name: "Featured Property", included: false },
        { name: "Top Property Placement", included: false },
      ],
    },
    {
      name: "BASIC PACKAGE",
      price: "₹249",
      originalPrice: "₹499",
      description: "Great for regular property listings",
      popular: true,
      features: [
        { name: "Property Submissions", included: true, value: "20" },
        { name: "Featured Properties", included: true, value: "5" },
        { name: "Basic Amenities Setup", included: true },
        { name: "Image Gallery", included: true, value: "20 photos" },
        { name: "Listing Validity", included: true, value: "60 Days" },
        { name: "Top Property Placement", included: false },
        { name: "Urgent Property Tag", included: false },
      ],
    },
    {
      name: "PRO PACKAGE",
      price: "₹499",
      originalPrice: "₹999",
      description: "Complete solution for professional agents",
      features: [
        { name: "Property Submissions", included: true, value: "50" },
        { name: "Featured Properties", included: true, value: "20" },
        { name: "Top Property Placements", included: true, value: "10" },
        { name: "Urgent Property Tags", included: true, value: "10" },
        { name: "Image Gallery", included: true, value: "50 photos" },
        { name: "Listing Validity", included: true, value: "90 Days" },
        { name: "Priority Support", included: true },
      ],
    },
  ];

  const testimonials = [
    {
      name: "Rajesh Mehra",
      image: testimonial1,
      property: "3BHK in Sector 45",
      testimonial:
        "Found my dream home within budget. KPrealtors made the entire process smooth and transparent.",
    },
    {
      name: "Priya Sharma",
      image: testimonial2,
      property: "2BHK in Sohna Road",
      testimonial:
        "Excellent service! The team helped me sell my apartment quickly at a great price.",
    },
    {
      name: "Amit Verma",
      image: testimonial3,
      property: "Office in Cyber City",
      testimonial:
        "Professional approach and deep market knowledge. Highly recommended for commercial properties.",
    },
  ];

  const handleEnquire = (propertyId: string) => {
    toast({
      title: "Enquiry Sent",
      description: "Our team will contact you shortly.",
    });
    console.log("Enquiry for property:", propertyId);
  };

  const handlePackageSelect = (packageName: string) => {
    toast({
      title: "Package Selected",
      description: `You selected ${packageName}. Redirecting to payment...`,
    });
    console.log("Package selected:", packageName);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <Hero
        backgroundImage={heroImage}
        title="Find Your Dream Property"
        subtitle="Discover premium properties at unbeatable prices with expert guidance"
        stats={[
          { label: "Properties", value: "5000+" },
          { label: "Verified Listings", value: "100%" },
          { label: "Expert Agents", value: "50+" },
          { label: "Quick Processing", value: "24hrs" },
        ]}
      />

      <section className="py-16 md:py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex items-center justify-between mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-featured-title">
                Featured Properties
              </h2>
              <p className="text-muted-foreground">
                Handpicked selection of the best properties in prime locations
              </p>
            </div>
            <Button
              variant="outline"
              onClick={() => setLocation("/properties")}
              data-testid="button-view-all"
            >
              View All
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProperties.map((property) => (
              <PropertyCard
                key={property.id}
                {...property}
                onEnquire={() => handleEnquire(property.id)}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-packages-title">
              Affordable Listing Packages
            </h2>
            <p className="text-muted-foreground text-lg">
              Budget-friendly packages to list and promote your properties effectively
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
            {packages.map((pkg) => (
              <PackageCard
                key={pkg.name}
                {...pkg}
                onSelect={() => handlePackageSelect(pkg.name)}
              />
            ))}
          </div>
        </div>
      </section>

      <HowItWorks
        steps={[
          {
            number: "01",
            icon: Search,
            title: "Search Property",
            description: "Browse through our extensive property listings",
          },
          {
            number: "02",
            icon: MapPin,
            title: "Visit & Select",
            description: "Schedule site visits and select your favorite",
          },
          {
            number: "03",
            icon: FileText,
            title: "Documentation",
            description: "Complete all legal formalities with our experts",
          },
          {
            number: "04",
            icon: PartyPopper,
            title: "Move In",
            description: "Get possession and start your new life",
          },
        ]}
      />

      <section className="py-16 md:py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-why-title">
              Why KP Realtors?
            </h2>
            <p className="text-muted-foreground text-lg">
              We provide end-to-end real estate solutions with transparency and expertise
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: Building2,
                title: "5000+ Properties",
                description: "Wide range of verified properties across all budgets",
              },
              {
                icon: Users,
                title: "Trusted Agents",
                description: "Certified and experienced real estate professionals",
              },
              {
                icon: DollarSign,
                title: "Best Prices",
                description: "Guaranteed best deals and transparent pricing",
              },
              {
                icon: Clock,
                title: "Quick Processing",
                description: "Fast documentation and hassle-free transactions",
              },
            ].map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="text-center p-6 rounded-lg hover-elevate transition-all"
                  data-testid={`feature-${index}`}
                >
                  <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                    <Icon className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 bg-card">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-testimonials-title">
              Client Success Stories
            </h2>
            <p className="text-muted-foreground text-lg">
              Hear from our satisfied clients who found their dream properties
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <TestimonialCard key={testimonial.name} {...testimonial} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-cta-title">
            Ready to Find Your Dream Property?
          </h2>
          <p className="text-xl mb-8 text-primary-foreground/90">
            Get started with KP Realtors and experience seamless property transactions
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              variant="secondary"
              className="px-8"
              asChild
              data-testid="button-cta-properties"
            >
              <Link href="/properties">Browse Properties</Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-8 bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20"
              data-testid="button-cta-call"
            >
              Call +91-97171 57006
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
