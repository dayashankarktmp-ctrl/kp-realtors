import { useState } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { majorCities } from "@shared/locations";

import property1 from "@assets/stock_images/luxury_3_bedroom_apa_8b57e0b2.jpg";
import property2 from "@assets/stock_images/modern_villa_house_e_58316048.jpg";
import property3 from "@assets/stock_images/contemporary_office__99483289.jpg";
import property4 from "@assets/stock_images/budget_apartment_bed_027a5ce7.jpg";
import property5 from "@assets/stock_images/agricultural_farmlan_f1d67d02.jpg";
import property6 from "@assets/stock_images/independent_house_re_a0b54a30.jpg";

export default function Properties() {
  const { toast } = useToast();
  const [propertyType, setPropertyType] = useState("all");
  const [budgetRange, setBudgetRange] = useState("all");
  const [location, setLocation] = useState("all");

  const allProperties = [
    {
      id: "1",
      image: property1,
      title: "Luxury 3BHK Apartment",
      type: "Apartment",
      location: "Sector 45, Gurgaon",
      price: "₹85,50,000",
      pricePerSqft: "₹7,500",
      beds: 3,
      baths: 2,
      sqft: 1140,
      featured: true,
    },
    {
      id: "2",
      image: property2,
      title: "Modern 4BHK Villa",
      type: "Villa",
      location: "DLF Phase 5, Gurgaon",
      price: "₹2.5 Cr",
      pricePerSqft: "₹12,000",
      beds: 4,
      baths: 3,
      sqft: 2080,
      featured: true,
      urgent: true,
    },
    {
      id: "3",
      image: property3,
      title: "Premium Office Space",
      type: "Commercial Shop",
      location: "Cyber City, Gurgaon",
      price: "₹1.2 Cr",
      pricePerSqft: "₹8,500",
      beds: 0,
      baths: 2,
      sqft: 1411,
      featured: true,
    },
    {
      id: "4",
      image: property4,
      title: "2BHK Budget Apartment",
      type: "Apartment",
      location: "Sohna Road, Gurgaon",
      price: "₹45,00,000",
      pricePerSqft: "₹6,200",
      beds: 2,
      baths: 2,
      sqft: 725,
      urgent: true,
    },
    {
      id: "5",
      image: property5,
      title: "Agriculture Land",
      type: "Agriculture Land",
      location: "Outskirts, Gurgaon",
      price: "₹75,00,000",
      pricePerSqft: "₹1,500",
      beds: 0,
      baths: 0,
      sqft: 5000,
      featured: true,
    },
    {
      id: "6",
      image: property6,
      title: "Independent House",
      type: "Independent House",
      location: "MG Road, Gurgaon",
      price: "₹3.2 Cr",
      pricePerSqft: "₹15,000",
      beds: 5,
      baths: 4,
      sqft: 2133,
      urgent: true,
    },
  ];

  const handleClearFilters = () => {
    setPropertyType("all");
    setBudgetRange("all");
    setLocation("all");
    console.log("Filters cleared");
  };

  const handleEnquire = (propertyId: string) => {
    toast({
      title: "Enquiry Sent",
      description: "Our team will contact you shortly.",
    });
    console.log("Enquiry for property:", propertyId);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <div className="bg-card border-b py-8">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <h1 className="text-4xl font-bold mb-2" data-testid="text-page-title">
            Browse Properties
          </h1>
          <p className="text-muted-foreground">
            Explore our collection of verified properties
          </p>
        </div>
      </div>

      <div className="sticky top-16 z-40 bg-background border-b py-4">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="flex flex-col md:flex-row gap-4 items-end">
            <div className="flex-1 space-y-2 w-full">
              <label className="text-sm font-medium">Property Type</label>
              <Select value={propertyType} onValueChange={setPropertyType}>
                <SelectTrigger data-testid="select-filter-type">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="apartment">Apartment</SelectItem>
                  <SelectItem value="villa">Villa</SelectItem>
                  <SelectItem value="house">Independent House</SelectItem>
                  <SelectItem value="commercial">Commercial Shop</SelectItem>
                  <SelectItem value="land">Agriculture Land</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 space-y-2 w-full">
              <label className="text-sm font-medium">Budget Range</label>
              <Select value={budgetRange} onValueChange={setBudgetRange}>
                <SelectTrigger data-testid="select-filter-budget">
                  <SelectValue placeholder="Any Budget" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Any Budget</SelectItem>
                  <SelectItem value="0-50">Up to ₹50L</SelectItem>
                  <SelectItem value="50-100">₹50L - ₹1Cr</SelectItem>
                  <SelectItem value="100-200">₹1Cr - ₹2Cr</SelectItem>
                  <SelectItem value="200+">Above ₹2Cr</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex-1 space-y-2 w-full">
              <label className="text-sm font-medium">City/State</label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger data-testid="select-filter-location">
                  <SelectValue placeholder="All Locations" />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  <SelectItem value="all">All India</SelectItem>
                  {majorCities.slice(0, 25).map((city) => (
                    <SelectItem key={city.value} value={city.value}>
                      {city.label}, {city.state}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              variant="outline"
              onClick={handleClearFilters}
              data-testid="button-clear-filters"
            >
              Clear Filters
            </Button>
          </div>
        </div>
      </div>

      <div className="flex-1 py-12">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="mb-6">
            <p className="text-muted-foreground" data-testid="text-results-count">
              Showing {allProperties.length} properties
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allProperties.map((property) => (
              <PropertyCard
                key={property.id}
                {...property}
                onEnquire={() => handleEnquire(property.id)}
              />
            ))}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
