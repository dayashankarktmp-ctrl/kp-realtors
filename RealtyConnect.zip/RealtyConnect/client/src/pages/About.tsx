import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Building2, Users, DollarSign, Clock, Award, Target } from "lucide-react";
import { Link } from "wouter";

export default function About() {
  const stats = [
    { icon: Building2, value: "5000+", label: "Properties Listed" },
    { icon: Users, value: "50+", label: "Expert Agents" },
    { icon: Award, value: "1000+", label: "Happy Clients" },
    { icon: Clock, value: "5+", label: "Years Experience" },
  ];

  const values = [
    {
      icon: Target,
      title: "Our Mission",
      description:
        "To provide transparent, efficient, and customer-centric real estate solutions that help people find their perfect property.",
    },
    {
      icon: Award,
      title: "Our Values",
      description:
        "Integrity, transparency, and customer satisfaction drive everything we do. We believe in building lasting relationships.",
    },
    {
      icon: Users,
      title: "Our Team",
      description:
        "Expert professionals with deep market knowledge and commitment to excellence in every transaction.",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="bg-card border-b py-16">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-page-title">
            About KP Realtors
          </h1>
          <p className="text-xl text-muted-foreground">
            Your trusted partner in real estate since 2019
          </p>
        </div>
      </div>

      <div className="flex-1">
        <section className="py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-3xl font-bold mb-6" data-testid="text-story-title">
                  Our Story
                </h2>
                <div className="space-y-4 text-muted-foreground leading-relaxed">
                  <p>
                    KP Realtors Group was founded in 2019 with a vision to transform the real
                    estate experience in Gurgaon. We recognized the need for a transparent,
                    customer-focused approach in an industry often plagued by complexity and
                    hidden costs.
                  </p>
                  <p>
                    Over the years, we've grown from a small team of passionate professionals
                    to one of the most trusted names in Gurgaon real estate. Our success is
                    built on the foundation of integrity, expertise, and unwavering commitment
                    to our clients' dreams.
                  </p>
                  <p>
                    Today, we're proud to have helped over 1000 families find their perfect
                    homes and assisted countless investors in making smart property decisions.
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => {
                  const Icon = stat.icon;
                  return (
                    <Card key={index} className="text-center">
                      <CardContent className="p-6">
                        <div className="w-12 h-12 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-4">
                          <Icon className="w-6 h-6 text-primary" />
                        </div>
                        <div className="text-3xl font-bold text-primary mb-1" data-testid={`stat-value-${index}`}>
                          {stat.value}
                        </div>
                        <div className="text-sm text-muted-foreground" data-testid={`stat-label-${index}`}>
                          {stat.label}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20 bg-card">
          <div className="max-w-7xl mx-auto px-4 md:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold mb-4">What Drives Us</h2>
              <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
                Our core values and mission guide every decision we make
              </p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {values.map((value, index) => {
                const Icon = value.icon;
                return (
                  <Card key={index} className="text-center">
                    <CardContent className="p-8">
                      <div className="w-16 h-16 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-6">
                        <Icon className="w-8 h-8 text-primary" />
                      </div>
                      <h3 className="text-xl font-semibold mb-3" data-testid={`value-title-${index}`}>
                        {value.title}
                      </h3>
                      <p className="text-muted-foreground" data-testid={`value-desc-${index}`}>
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>
        </section>

        <section className="py-16 md:py-20">
          <div className="max-w-7xl mx-auto px-4 md:px-8">
            <Card className="bg-primary text-primary-foreground">
              <CardContent className="p-12 text-center">
                <h2 className="text-3xl font-bold mb-4" data-testid="text-cta-title">
                  Ready to Work With Us?
                </h2>
                <p className="text-xl mb-8 text-primary-foreground/90 max-w-2xl mx-auto">
                  Whether you're buying, selling, or investing, our team is here to guide
                  you every step of the way.
                </p>
                <div className="flex flex-wrap justify-center gap-4">
                  <Button
                    size="lg"
                    variant="secondary"
                    className="px-8"
                    asChild
                    data-testid="button-cta-properties"
                  >
                    <Link href="/properties">Browse Properties</Link>
                  </Button>
                  <Button
                    size="lg"
                    variant="outline"
                    className="px-8 bg-primary-foreground/10 border-primary-foreground/30 text-primary-foreground hover:bg-primary-foreground/20"
                    asChild
                    data-testid="button-cta-agent"
                  >
                    <Link href="/agent-signup">Become an Agent</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}
