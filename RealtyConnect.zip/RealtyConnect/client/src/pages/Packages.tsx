import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PackageCard from "@/components/PackageCard";
import { Card, CardContent } from "@/components/ui/card";
import { Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Packages() {
  const { toast } = useToast();

  const packages = [
    {
      name: "STARTER PACKAGE",
      price: "₹99",
      originalPrice: "₹199",
      description: "Perfect for individual property sellers",
      features: [
        { name: "Property Submissions", included: true, value: "10" },
        { name: "Basic Amenities Setup", included: true },
        { name: "Nearest Location Tags", included: true },
        { name: "Additional Information", included: true },
        { name: "Image Gallery", included: true, value: "10 photos" },
        { name: "Listing Validity", included: true, value: "30 Days" },
        { name: "Featured Property", included: false },
        { name: "Top Property Placement", included: false },
        { name: "Urgent Property Tag", included: false },
        { name: "Property Plan Upload", included: false },
      ],
    },
    {
      name: "BASIC PACKAGE",
      price: "₹249",
      originalPrice: "₹499",
      description: "Great for regular property listings",
      popular: true,
      features: [
        { name: "Property Submissions", included: true, value: "20" },
        { name: "Featured Properties", included: true, value: "5" },
        { name: "Basic Amenities Setup", included: true },
        { name: "Nearest Location Tags", included: true },
        { name: "Additional Information", included: true },
        { name: "Image Gallery", included: true, value: "20 photos" },
        { name: "Listing Validity", included: true, value: "60 Days" },
        { name: "Top Property Placement", included: false },
        { name: "Urgent Property Tag", included: false },
        { name: "Property Plan Upload", included: false },
      ],
    },
    {
      name: "PRO PACKAGE",
      price: "₹499",
      originalPrice: "₹999",
      description: "Complete solution for professional agents",
      features: [
        { name: "Property Submissions", included: true, value: "50" },
        { name: "Featured Properties", included: true, value: "20" },
        { name: "Top Property Placements", included: true, value: "10" },
        { name: "Urgent Property Tags", included: true, value: "10" },
        { name: "Advanced Amenities Setup", included: true },
        { name: "Nearest Location Tags", included: true },
        { name: "Property Plan Upload", included: true },
        { name: "Additional Information", included: true },
        { name: "Image Gallery", included: true, value: "50 photos" },
        { name: "Priority Support", included: true },
        { name: "Listing Validity", included: true, value: "90 Days" },
      ],
    },
  ];

  const handlePackageSelect = (packageName: string) => {
    toast({
      title: "Package Selected",
      description: `You selected ${packageName}. Redirecting to payment...`,
    });
    console.log("Package selected:", packageName);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="bg-card border-b py-16">
        <div className="max-w-4xl mx-auto px-4 md:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4" data-testid="text-page-title">
            Affordable Listing Packages
          </h1>
          <p className="text-xl text-muted-foreground">
            Budget-friendly packages to list and promote your properties effectively
          </p>
        </div>
      </div>

      <div className="flex-1 py-16">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-12">
            {packages.map((pkg) => (
              <PackageCard
                key={pkg.name}
                {...pkg}
                onSelect={() => handlePackageSelect(pkg.name)}
              />
            ))}
          </div>

          <Card className="max-w-3xl mx-auto">
            <CardContent className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                  <Shield className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2" data-testid="text-security-title">
                    Secure Payment Processing
                  </h3>
                  <p className="text-muted-foreground" data-testid="text-security-desc">
                    All payments are securely processed through Razorpay. We support UPI,
                    Credit/Debit Cards, Net Banking, and Wallets. Your financial information
                    is protected with bank-level security.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
