import { useRoute } from "wouter";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Bed,
  Bath,
  Maximize,
  MapPin,
  Phone,
  Mail,
  CheckCircle2,
  ArrowLeft,
} from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";

import property1 from "@assets/stock_images/luxury_3_bedroom_apa_8b57e0b2.jpg";
import property2 from "@assets/stock_images/modern_villa_house_e_58316048.jpg";
import property3 from "@assets/stock_images/contemporary_office__99483289.jpg";

export default function PropertyDetail() {
  const [, params] = useRoute("/property/:id");
  const { toast } = useToast();

  const property = {
    id: params?.id || "1",
    images: [property1, property1, property1],
    title: "Luxury 3BHK Apartment",
    type: "Apartment",
    location: "Sector 45, Gurgaon",
    price: "₹85,50,000",
    pricePerSqft: "₹7,500",
    beds: 3,
    baths: 2,
    sqft: 1140,
    featured: true,
    description:
      "Experience luxury living in this beautifully designed 3BHK apartment located in the heart of Sector 45, Gurgaon. This property features modern amenities, spacious rooms, and excellent connectivity to major landmarks.",
    amenities: [
      "24/7 Security",
      "Power Backup",
      "Parking",
      "Gym",
      "Swimming Pool",
      "Club House",
      "Children Play Area",
      "Elevator",
      "Intercom",
      "Park",
      "Water Supply",
      "Maintenance Staff",
    ],
  };

  const similarProperties = [
    {
      id: "2",
      image: property2,
      title: "Modern 4BHK Villa",
      type: "Villa",
      location: "DLF Phase 5, Gurgaon",
      price: "₹2.5 Cr",
      pricePerSqft: "₹12,000",
      beds: 4,
      baths: 3,
      sqft: 2080,
      featured: true,
    },
    {
      id: "3",
      image: property3,
      title: "Premium Office Space",
      type: "Commercial Shop",
      location: "Cyber City, Gurgaon",
      price: "₹1.2 Cr",
      pricePerSqft: "₹8,500",
      beds: 0,
      baths: 2,
      sqft: 1411,
    },
  ];

  const handleContact = () => {
    toast({
      title: "Contact Request Sent",
      description: "Our agent will reach out to you shortly.",
    });
    console.log("Contact agent clicked");
  };

  const handleEnquire = () => {
    toast({
      title: "Enquiry Sent",
      description: "We'll get back to you with more details.",
    });
    console.log("Enquire clicked");
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />

      <div className="flex-1">
        <div className="max-w-7xl mx-auto px-4 md:px-8 py-8">
          <Button
            variant="ghost"
            className="mb-6"
            asChild
            data-testid="button-back"
          >
            <Link href="/properties">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Properties
            </Link>
          </Button>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="aspect-video relative rounded-xl overflow-hidden">
                <img
                  src={property.images[0]}
                  alt={property.title}
                  className="w-full h-full object-cover"
                  data-testid="img-property-main"
                />
                <div className="absolute top-4 right-4 flex gap-2">
                  {property.featured && (
                    <Badge className="bg-primary text-primary-foreground">
                      Featured
                    </Badge>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                {property.images.slice(1).map((img, idx) => (
                  <div
                    key={idx}
                    className="aspect-video rounded-lg overflow-hidden"
                  >
                    <img
                      src={img}
                      alt={`${property.title} ${idx + 2}`}
                      className="w-full h-full object-cover hover-elevate transition-all cursor-pointer"
                      data-testid={`img-gallery-${idx}`}
                    />
                  </div>
                ))}
              </div>

              <div>
                <Badge variant="secondary" className="mb-3">
                  {property.type}
                </Badge>
                <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-property-title">
                  {property.title}
                </h1>
                <div className="flex items-center gap-2 text-muted-foreground mb-4">
                  <MapPin className="w-5 h-5" />
                  <span data-testid="text-property-location">{property.location}</span>
                </div>
                <div className="flex items-baseline gap-3 mb-6">
                  <span className="text-4xl font-bold text-primary" data-testid="text-property-price">
                    {property.price}
                  </span>
                  <span className="text-muted-foreground">
                    {property.pricePerSqft}/sq.ft
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-4 p-6 bg-card rounded-lg border">
                  {property.beds > 0 && (
                    <div className="text-center">
                      <Bed className="w-6 h-6 mx-auto mb-2 text-primary" />
                      <div className="font-semibold">{property.beds}</div>
                      <div className="text-sm text-muted-foreground">Bedrooms</div>
                    </div>
                  )}
                  <div className="text-center">
                    <Bath className="w-6 h-6 mx-auto mb-2 text-primary" />
                    <div className="font-semibold">{property.baths}</div>
                    <div className="text-sm text-muted-foreground">Bathrooms</div>
                  </div>
                  <div className="text-center">
                    <Maximize className="w-6 h-6 mx-auto mb-2 text-primary" />
                    <div className="font-semibold">{property.sqft.toLocaleString()}</div>
                    <div className="text-sm text-muted-foreground">Sq.ft</div>
                  </div>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Description</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed" data-testid="text-description">
                    {property.description}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Amenities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {property.amenities.map((amenity, idx) => (
                      <div key={idx} className="flex items-center gap-2" data-testid={`amenity-${idx}`}>
                        <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0" />
                        <span className="text-sm">{amenity}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle>Contact Agent</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                      <Phone className="w-5 h-5 text-primary" />
                      <div>
                        <div className="text-sm text-muted-foreground">Phone</div>
                        <div className="font-medium">+91-97171 57006</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                      <Mail className="w-5 h-5 text-primary" />
                      <div>
                        <div className="text-sm text-muted-foreground">Email</div>
                        <div className="font-medium">info@kprealtors.com</div>
                      </div>
                    </div>
                  </div>
                  <Button
                    className="w-full"
                    onClick={handleContact}
                    data-testid="button-contact-agent"
                  >
                    Contact Agent
                  </Button>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={handleEnquire}
                    data-testid="button-schedule-visit"
                  >
                    Schedule Visit
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6" data-testid="text-similar-title">
              Similar Properties
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {similarProperties.map((prop) => (
                <PropertyCard
                  key={prop.id}
                  {...prop}
                  onEnquire={() => console.log("Enquire:", prop.id)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
