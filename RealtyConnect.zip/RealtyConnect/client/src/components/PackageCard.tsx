import { Card, CardHeader, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X } from "lucide-react";

export interface PackageFeature {
  name: string;
  included: boolean;
  value?: string;
}

export interface PackageCardProps {
  name: string;
  price: string;
  originalPrice?: string;
  description: string;
  features: PackageFeature[];
  popular?: boolean;
  onSelect?: () => void;
}

export default function PackageCard({
  name,
  price,
  originalPrice,
  description,
  features,
  popular,
  onSelect,
}: PackageCardProps) {
  return (
    <Card className={`relative ${popular ? "border-primary shadow-lg" : ""}`}>
      {popular && (
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <Badge className="bg-accent text-accent-foreground px-4 py-1" data-testid="badge-popular">
            MOST POPULAR
          </Badge>
        </div>
      )}
      <CardHeader className="space-y-4 pb-4">
        <div>
          <h3 className="text-2xl font-bold" data-testid={`text-package-name-${name}`}>
            {name}
          </h3>
          <p className="text-sm text-muted-foreground mt-1" data-testid={`text-package-desc-${name}`}>
            {description}
          </p>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-4xl font-bold text-primary" data-testid={`text-package-price-${name}`}>
            {price}
          </span>
          {originalPrice && (
            <span className="text-lg text-muted-foreground line-through" data-testid={`text-package-original-${name}`}>
              {originalPrice}
            </span>
          )}
        </div>
        {originalPrice && (
          <Badge variant="secondary" className="w-fit">
            Save {parseInt(originalPrice.replace(/[^0-9]/g, "")) - parseInt(price.replace(/[^0-9]/g, ""))}
          </Badge>
        )}
      </CardHeader>
      <CardContent className="space-y-3">
        {features.map((feature, index) => (
          <div
            key={index}
            className="flex items-start gap-3"
            data-testid={`feature-${name}-${index}`}
          >
            {feature.included ? (
              <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
            ) : (
              <X className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
            )}
            <div className="flex-1">
              <span className={feature.included ? "" : "text-muted-foreground"}>
                {feature.name}
              </span>
              {feature.value && (
                <span className="text-sm text-muted-foreground ml-1">({feature.value})</span>
              )}
            </div>
          </div>
        ))}
      </CardContent>
      <CardFooter className="flex-col gap-3">
        <Button
          className="w-full"
          variant={popular ? "default" : "outline"}
          onClick={onSelect}
          data-testid={`button-select-${name}`}
        >
          Pay {price}
        </Button>
        <Button
          variant="ghost"
          className="w-full"
          data-testid={`button-whatsapp-${name}`}
        >
          Get Info on WhatsApp
        </Button>
      </CardFooter>
    </Card>
  );
}
