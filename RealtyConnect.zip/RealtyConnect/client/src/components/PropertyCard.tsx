import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Bed, Bath, Maximize, MapPin, Phone } from "lucide-react";
import { Link, useLocation } from "wouter";

export interface PropertyCardProps {
  id: string;
  image: string;
  title: string;
  type: string;
  location: string;
  price: string;
  pricePerSqft?: string;
  beds: number;
  baths: number;
  sqft: number;
  featured?: boolean;
  urgent?: boolean;
  onEnquire?: () => void;
}

export default function PropertyCard({
  id,
  image,
  title,
  type,
  location,
  price,
  pricePerSqft,
  beds,
  baths,
  sqft,
  featured,
  urgent,
  onEnquire,
}: PropertyCardProps) {
  const [, setLocation] = useLocation();
  
  return (
    <Card className="overflow-hidden hover-elevate transition-all duration-300">
      <div className="relative aspect-[4/3]">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover"
          data-testid={`img-property-${id}`}
        />
        <div className="absolute top-3 right-3 flex gap-2">
          {featured && (
            <Badge className="bg-primary text-primary-foreground" data-testid={`badge-featured-${id}`}>
              Featured
            </Badge>
          )}
          {urgent && (
            <Badge className="bg-accent text-accent-foreground" data-testid={`badge-urgent-${id}`}>
              Urgent
            </Badge>
          )}
        </div>
      </div>
      <div className="p-4 space-y-3">
        <div>
          <Badge variant="secondary" className="mb-2" data-testid={`badge-type-${id}`}>
            {type}
          </Badge>
          <Link href={`/property/${id}`}>
            <h3 className="text-lg font-semibold hover:text-primary transition-colors" data-testid={`text-title-${id}`}>
              {title}
            </h3>
          </Link>
          <div className="flex items-center gap-1 text-sm text-muted-foreground mt-1">
            <MapPin className="w-4 h-4" />
            <span data-testid={`text-location-${id}`}>{location}</span>
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold text-primary" data-testid={`text-price-${id}`}>
            {price}
          </span>
          {pricePerSqft && (
            <span className="text-sm text-muted-foreground" data-testid={`text-price-sqft-${id}`}>
              {pricePerSqft}/sq.ft
            </span>
          )}
        </div>
        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          {beds > 0 && (
            <div className="flex items-center gap-1" data-testid={`text-beds-${id}`}>
              <Bed className="w-4 h-4" />
              <span>{beds} Beds</span>
            </div>
          )}
          {baths > 0 && (
            <div className="flex items-center gap-1" data-testid={`text-baths-${id}`}>
              <Bath className="w-4 h-4" />
              <span>{baths} Baths</span>
            </div>
          )}
          <div className="flex items-center gap-1" data-testid={`text-sqft-${id}`}>
            <Maximize className="w-4 h-4" />
            <span>{sqft.toLocaleString()} sq.ft</span>
          </div>
        </div>
        <div className="flex gap-2 pt-2">
          <Button
            variant="default"
            className="flex-1"
            onClick={() => setLocation(`/property/${id}`)}
            data-testid={`button-view-${id}`}
          >
            View Details
          </Button>
          <Button
            variant="outline"
            size="icon"
            onClick={onEnquire}
            data-testid={`button-enquire-${id}`}
          >
            <Phone className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
}
