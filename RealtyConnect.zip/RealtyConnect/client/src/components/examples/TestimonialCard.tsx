import TestimonialCard from "../TestimonialCard";
import testimonialImage from "@assets/stock_images/professional_real_es_7e21f9ed.jpg";

export default function TestimonialCardExample() {
  return (
    <div className="max-w-md p-8">
      <TestimonialCard
        name="Rajesh Mehra"
        image={testimonialImage}
        property="3BHK in Sector 45"
        testimonial="Found my dream home within budget. KPrealtors made the entire process smooth and transparent."
      />
    </div>
  );
}
