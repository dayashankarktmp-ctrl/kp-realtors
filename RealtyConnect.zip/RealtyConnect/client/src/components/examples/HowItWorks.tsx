import HowItWorks from "../HowItWorks";
import { Search, MapPin, FileText, PartyPopper } from "lucide-react";

export default function HowItWorksExample() {
  return (
    <HowItWorks
      steps={[
        {
          number: "01",
          icon: Search,
          title: "Search Property",
          description: "Browse through our extensive property listings",
        },
        {
          number: "02",
          icon: MapPin,
          title: "Visit & Select",
          description: "Schedule site visits and select your favorite",
        },
        {
          number: "03",
          icon: FileText,
          title: "Documentation",
          description: "Complete all legal formalities with our experts",
        },
        {
          number: "04",
          icon: PartyPopper,
          title: "Move In",
          description: "Get possession and start your new life",
        },
      ]}
    />
  );
}
