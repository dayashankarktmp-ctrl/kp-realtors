import PackageCard from "../PackageCard";

export default function PackageCardExample() {
  return (
    <div className="max-w-sm p-8">
      <PackageCard
        name="BASIC PACKAGE"
        price="₹249"
        originalPrice="₹499"
        description="Great for regular property listings"
        popular
        features={[
          { name: "Property Submissions", included: true, value: "20" },
          { name: "Featured Properties", included: true, value: "5" },
          { name: "Basic Amenities Setup", included: true },
          { name: "Image Gallery", included: true, value: "20 photos" },
          { name: "Listing Validity", included: true, value: "60 Days" },
          { name: "Top Property Placement", included: false },
          { name: "Urgent Property Tag", included: false },
        ]}
        onSelect={() => console.log("Package selected")}
      />
    </div>
  );
}
