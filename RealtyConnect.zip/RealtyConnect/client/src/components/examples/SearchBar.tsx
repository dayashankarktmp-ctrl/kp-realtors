import SearchBar from "../SearchBar";

export default function SearchBarExample() {
  return (
    <div className="p-8">
      <SearchBar variant="hero" />
    </div>
  );
}
