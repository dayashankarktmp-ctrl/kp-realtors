import Hero from "../Hero";
import heroImage from "@assets/stock_images/modern_luxury_apartm_0405f809.jpg";

export default function HeroExample() {
  return (
    <Hero
      backgroundImage={heroImage}
      title="Find Your Dream Property"
      subtitle="Discover premium properties at unbeatable prices with expert guidance"
      stats={[
        { label: "Properties", value: "5000+" },
        { label: "Verified Listings", value: "100%" },
        { label: "Expert Agents", value: "50+" },
        { label: "Quick Processing", value: "24hrs" },
      ]}
    />
  );
}
