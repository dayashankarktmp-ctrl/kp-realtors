import PropertyCard from "../PropertyCard";
import propertyImage from "@assets/stock_images/luxury_3_bedroom_apa_8b57e0b2.jpg";

export default function PropertyCardExample() {
  return (
    <div className="max-w-sm">
      <PropertyCard
        id="1"
        image={propertyImage}
        title="Luxury 3BHK Apartment"
        type="Apartment"
        location="Sector 45, Gurgaon"
        price="₹85,50,000"
        pricePerSqft="₹7,500"
        beds={3}
        baths={2}
        sqft={1140}
        featured
        onEnquire={() => console.log("Enquire clicked")}
      />
    </div>
  );
}
