import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Search } from "lucide-react";
import { useState } from "react";
import { majorCities, indianStates } from "@shared/locations";

export interface SearchBarProps {
  onSearch?: (filters: {
    propertyType: string;
    budgetRange: string;
    location: string;
  }) => void;
  variant?: "hero" | "inline";
}

export default function SearchBar({ onSearch, variant = "inline" }: SearchBarProps) {
  const [propertyType, setPropertyType] = useState("");
  const [budgetRange, setBudgetRange] = useState("");
  const [location, setLocation] = useState("");

  const handleSearch = () => {
    onSearch?.({ propertyType, budgetRange, location });
    console.log("Search:", { propertyType, budgetRange, location });
  };

  const isHero = variant === "hero";

  return (
    <div
      className={`${
        isHero
          ? "bg-background/95 backdrop-blur-md shadow-2xl rounded-xl p-6"
          : "bg-card border border-card-border rounded-lg p-4"
      } flex flex-col md:flex-row gap-4 items-end`}
    >
      <div className="flex-1 space-y-2 w-full">
        <label className="text-sm font-medium" data-testid="label-property-type">
          Property Type
        </label>
        <Select value={propertyType} onValueChange={setPropertyType}>
          <SelectTrigger data-testid="select-property-type">
            <SelectValue placeholder="Select Property Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="apartment">Apartment</SelectItem>
            <SelectItem value="villa">Villa</SelectItem>
            <SelectItem value="house">Independent House</SelectItem>
            <SelectItem value="floor">Independent Floor</SelectItem>
            <SelectItem value="commercial">Commercial Shop</SelectItem>
            <SelectItem value="land">Agriculture Land</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1 space-y-2 w-full">
        <label className="text-sm font-medium" data-testid="label-budget">
          Budget Range
        </label>
        <Select value={budgetRange} onValueChange={setBudgetRange}>
          <SelectTrigger data-testid="select-budget">
            <SelectValue placeholder="Select Budget Range" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0-50">Up to ₹50L</SelectItem>
            <SelectItem value="50-100">₹50L - ₹1Cr</SelectItem>
            <SelectItem value="100-200">₹1Cr - ₹2Cr</SelectItem>
            <SelectItem value="200-500">₹2Cr - ₹5Cr</SelectItem>
            <SelectItem value="500+">Above ₹5Cr</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex-1 space-y-2 w-full">
        <label className="text-sm font-medium" data-testid="label-location">
          City/Location
        </label>
        <Select value={location} onValueChange={setLocation}>
          <SelectTrigger data-testid="select-location">
            <SelectValue placeholder="Select City" />
          </SelectTrigger>
          <SelectContent className="max-h-[300px]">
            {majorCities.slice(0, 20).map((city) => (
              <SelectItem key={city.value} value={city.value}>
                {city.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button
        size="default"
        className={isHero ? "px-8" : ""}
        onClick={handleSearch}
        data-testid="button-search"
      >
        <Search className="w-4 h-4 mr-2" />
        Search Properties
      </Button>
    </div>
  );
}
