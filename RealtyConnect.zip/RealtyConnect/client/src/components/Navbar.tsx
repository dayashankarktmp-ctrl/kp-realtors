import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { Menu, X } from "lucide-react";
import { useState } from "react";

function NavButton({ href, children, variant = "default", className = "", testId }: { href: string; children: React.ReactNode; variant?: "default" | "outline" | "ghost"; className?: string; testId: string }) {
  const [, setLocation] = useLocation();
  return (
    <Button
      variant={variant}
      className={className}
      onClick={() => setLocation(href)}
      data-testid={testId}
    >
      {children}
    </Button>
  );
}

export default function Navbar() {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Home" },
    { href: "/properties", label: "Buy" },
    { href: "/rent", label: "Rent" },
    { href: "/packages", label: "Packages" },
    { href: "/about", label: "About" },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-background/95 backdrop-blur-md border-b">
      <div className="max-w-7xl mx-auto px-4 md:px-8">
        <div className="flex items-center justify-between h-16">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer" data-testid="link-logo">
              <div className="w-10 h-10 bg-primary rounded-md flex items-center justify-center">
                <span className="text-white font-bold text-xl">KP</span>
              </div>
              <span className="font-bold text-xl hidden sm:inline">KP Realtors</span>
            </div>
          </Link>

          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-medium transition-colors hover:text-primary cursor-pointer ${
                    location === link.href ? "text-primary" : "text-foreground"
                  }`}
                  data-testid={`link-${link.label.toLowerCase()}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-4">
            <NavButton href="/register" variant="ghost" testId="button-register">
              Register
            </NavButton>
            <NavButton href="/agent-signup" variant="outline" testId="button-agent-signup">
              Agent Signup
            </NavButton>
            <NavButton href="/agent-signup" testId="button-list-property">
              List Property
            </NavButton>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </Button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t bg-background">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`block py-2 text-sm font-medium cursor-pointer ${
                    location === link.href ? "text-primary" : "text-foreground"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                  data-testid={`link-mobile-${link.label.toLowerCase()}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}
            <div className="flex flex-col gap-2 pt-4">
              <NavButton href="/register" variant="ghost" className="w-full" testId="button-mobile-register">
                Register
              </NavButton>
              <NavButton href="/agent-signup" variant="outline" className="w-full" testId="button-mobile-agent">
                Agent Signup
              </NavButton>
              <NavButton href="/agent-signup" className="w-full" testId="button-mobile-list">
                List Property
              </NavButton>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
