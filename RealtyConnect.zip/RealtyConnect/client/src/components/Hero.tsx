import SearchBar from "./SearchBar";
import { Button } from "@/components/ui/button";
import { Phone } from "lucide-react";

export interface HeroProps {
  backgroundImage: string;
  title: string;
  subtitle: string;
  showSearch?: boolean;
  stats?: Array<{ label: string; value: string }>;
}

export default function Hero({
  backgroundImage,
  title,
  subtitle,
  showSearch = true,
  stats,
}: HeroProps) {
  return (
    <div className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${backgroundImage})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/50 to-black/70" />
      
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 md:px-8 py-16">
        <div className="text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4" data-testid="text-hero-title">
            {title}
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-8" data-testid="text-hero-subtitle">
            {subtitle}
          </p>
          {stats && (
            <div className="flex flex-wrap justify-center gap-8 mb-8">
              {stats.map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="text-3xl font-bold text-white" data-testid={`text-stat-value-${index}`}>
                    {stat.value}
                  </div>
                  <div className="text-sm text-white/80" data-testid={`text-stat-label-${index}`}>
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          )}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <Button
              size="lg"
              className="px-8"
              data-testid="button-browse-properties"
            >
              Browse Properties
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="px-8 bg-background/20 backdrop-blur-sm border-white/30 text-white hover:bg-background/30"
              data-testid="button-call"
            >
              <Phone className="w-4 h-4 mr-2" />
              Call +91-97171 57006
            </Button>
          </div>
        </div>
        {showSearch && (
          <div className="max-w-5xl mx-auto">
            <SearchBar variant="hero" />
          </div>
        )}
      </div>
    </div>
  );
}
