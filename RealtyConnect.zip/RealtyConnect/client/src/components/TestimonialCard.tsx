import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Quote } from "lucide-react";

export interface TestimonialCardProps {
  name: string;
  image?: string;
  property: string;
  testimonial: string;
}

export default function TestimonialCard({
  name,
  image,
  property,
  testimonial,
}: TestimonialCardProps) {
  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <Card className="h-full">
      <CardContent className="p-6 space-y-4">
        <Quote className="w-8 h-8 text-primary" />
        <p className="text-muted-foreground leading-relaxed" data-testid={`text-testimonial-${name}`}>
          "{testimonial}"
        </p>
        <div className="flex items-center gap-4 pt-4 border-t">
          <Avatar>
            {image && <AvatarImage src={image} alt={name} />}
            <AvatarFallback>{initials}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-semibold" data-testid={`text-name-${name}`}>
              {name}
            </div>
            <div className="text-sm text-muted-foreground" data-testid={`text-property-${name}`}>
              {property}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
