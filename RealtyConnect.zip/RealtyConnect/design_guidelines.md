# Real Estate Platform Design Guidelines

## Design Approach
**Reference-Based Approach**: Drawing inspiration from Airbnb's card-based property presentation, Zillow's advanced search patterns, and modern real estate platforms that balance visual appeal with functional browsing.

## Typography Hierarchy

**Font Stack**: 
- Primary: Inter or DM Sans (clean, modern sans-serif via Google Fonts)
- Headings: Bold weights (700) for impact
- Body: Regular (400) and Medium (500) weights

**Scale**:
- Hero Headlines: text-5xl to text-6xl, font-bold
- Section Headers: text-3xl to text-4xl, font-bold
- Property Titles: text-xl, font-semibold
- Card Metadata: text-sm, font-medium
- Body Text: text-base, leading-relaxed
- Price Tags: text-2xl to text-3xl, font-bold for primary prices

## Layout System

**Spacing Primitives**: Use Tailwind units of 4, 6, 8, 12, 16, 20, 24 for consistency
- Container padding: px-4 md:px-8 lg:px-12
- Section spacing: py-16 md:py-20 lg:py-24
- Card internal padding: p-4 to p-6
- Grid gaps: gap-6 to gap-8

**Container Strategy**:
- Full-width sections: w-full with inner max-w-7xl mx-auto
- Content sections: max-w-6xl mx-auto
- Property grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3

## Core Page Structures

### Homepage
1. **Hero Section** (90vh): Large property image background with overlay, centered search widget with dropdowns (Property Type, Budget Range, Location), prominent CTA buttons with backdrop blur
2. **Featured Properties Grid**: 3-column responsive grid (1/2/3), property cards with hover lift effect
3. **Package Comparison**: 3-column pricing table with feature checkmarks, highlighted "Most Popular" badge
4. **How It Works**: 4-step horizontal flow with numbered icons and descriptions
5. **Testimonials**: 3-column grid with client photos, quotes, property purchased
6. **Final CTA Section**: Split layout - left side with headline/subheadline, right side with contact form

### Property Listing Page
- **Search Bar**: Sticky top filter bar with dropdowns and "Clear Filters" button
- **Results Grid**: 3-column property cards (2 on tablet, 1 on mobile)
- **Sidebar Filters** (desktop): Property type checkboxes, price range slider, location multi-select, beds/baths selectors

### Property Detail Page
- **Image Gallery**: Large hero image (60vh) with thumbnail carousel below, fullscreen lightbox capability
- **Details Panel**: 2-column split - left: specs grid (beds, baths, sq.ft, price/sq.ft), right: agent contact card
- **Amenities Grid**: 4-column icon grid with labels
- **Location Map**: Embedded map section with nearby landmarks list
- **Similar Properties**: 3-column carousel at bottom

### Package Selection Page
- **Comparison Table**: 3 pricing tiers side-by-side, feature rows with checkmarks/crosses, sticky headers on scroll
- **Payment CTA**: Large buttons with secure payment badge below

## Component Library

### Property Cards
- Aspect ratio 4:3 for images with object-cover
- Absolute positioned badges (Featured, Urgent) top-right corner with px-3 py-1 text-xs
- Card shadow: shadow-md hover:shadow-xl transition
- Bottom section: Title (text-lg font-semibold), location (text-sm with map pin icon), price (text-2xl font-bold), specs row (beds/baths/sqft with icons)
- Rounded corners: rounded-xl

### Search Widget
- Grouped dropdown selects with subtle borders
- Search button: Large, rounded-full, with arrow icon
- Min height: 64px for touch targets
- Floating card style with shadow-2xl

### Navigation
- Sticky header with logo left, main nav center, "List Property" CTA button right
- Mobile: Hamburger menu with full-screen overlay
- Footer: 4-column grid (Quick Links, For Buyers, For Sellers, Contact) with newsletter signup

### Forms
- Input fields: rounded-lg border with focus ring effect
- Labels: text-sm font-medium mb-2
- Multi-step forms for property submission with progress indicator
- File upload: Drag-and-drop zone with preview thumbnails

### Buttons
- Primary CTAs: px-8 py-3 rounded-lg text-base font-semibold
- Secondary: px-6 py-2 rounded-lg border
- Icon buttons: Square with p-3, rounded-lg
- On image overlays: backdrop-blur-sm with semi-transparent background

## Images

**Homepage**:
- Hero: High-quality modern apartment exterior or interior (1920x1080 min)
- Featured properties: 6 diverse property images (luxury apartments, villas, commercial spaces, budget homes)

**Property Listings**:
- Each property card: Primary exterior/interior shot
- Detail pages: 8-12 professional photos per property

**About Page**:
- Team photo or office image
- City skyline or local landmark establishing shot

**Package Section**:
- Icon illustrations for package features (not photos)

## Interaction Patterns

- Property card hover: Subtle scale (scale-105) with shadow increase
- Image galleries: Smooth carousel with dot indicators, 500ms transitions
- Filter dropdowns: Slide-down animation with 200ms duration
- Infinite scroll for property listings with loading spinner
- Toast notifications for save/shortlist actions
- Modal overlays for quick property preview without page navigation

## Responsive Breakpoints
- Mobile: Base styles, single column layouts
- Tablet (md: 768px): 2-column grids, horizontal navigation
- Desktop (lg: 1024px): 3-column grids, all features visible
- Large (xl: 1280px): Max container width, enhanced spacing

## Accessibility
- All interactive elements min 44x44px touch targets
- Form inputs with visible labels and error states
- Skip navigation link for keyboard users
- Image alt text describing property type and location
- ARIA labels for icon-only buttons
- Focus indicators with 2px outline offset