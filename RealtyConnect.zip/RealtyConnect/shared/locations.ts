// Indian States and Major Cities for Location Filtering
export const indianStates = [
  { value: "andhra-pradesh", label: "Andhra Pradesh" },
  { value: "arunachal-pradesh", label: "Arunachal Pradesh" },
  { value: "assam", label: "Assam" },
  { value: "bihar", label: "Bihar" },
  { value: "chhattisgarh", label: "Chhattisgarh" },
  { value: "goa", label: "Goa" },
  { value: "gujarat", label: "Gujarat" },
  { value: "haryana", label: "Haryana" },
  { value: "himachal-pradesh", label: "Himachal Pradesh" },
  { value: "jharkhand", label: "Jharkhand" },
  { value: "karnataka", label: "Karnataka" },
  { value: "kerala", label: "Kerala" },
  { value: "madhya-pradesh", label: "Madhya Pradesh" },
  { value: "maharashtra", label: "Maharashtra" },
  { value: "manipur", label: "Manipur" },
  { value: "meghalaya", label: "Meghalaya" },
  { value: "mizoram", label: "Mizoram" },
  { value: "nagaland", label: "Nagaland" },
  { value: "odisha", label: "Odisha" },
  { value: "punjab", label: "Punjab" },
  { value: "rajasthan", label: "Rajasthan" },
  { value: "sikkim", label: "Sikkim" },
  { value: "tamil-nadu", label: "Tamil Nadu" },
  { value: "telangana", label: "Telangana" },
  { value: "tripura", label: "Tripura" },
  { value: "uttar-pradesh", label: "Uttar Pradesh" },
  { value: "uttarakhand", label: "Uttarakhand" },
  { value: "west-bengal", label: "West Bengal" },
  { value: "delhi", label: "Delhi" },
  { value: "jammu-kashmir", label: "Jammu & Kashmir" },
  { value: "ladakh", label: "Ladakh" },
  { value: "puducherry", label: "Puducherry" },
];

export const majorCities = [
  // Metro Cities
  { value: "mumbai", label: "Mumbai", state: "Maharashtra" },
  { value: "delhi", label: "Delhi", state: "Delhi" },
  { value: "bangalore", label: "Bangalore", state: "Karnataka" },
  { value: "hyderabad", label: "Hyderabad", state: "Telangana" },
  { value: "chennai", label: "Chennai", state: "Tamil Nadu" },
  { value: "kolkata", label: "Kolkata", state: "West Bengal" },
  { value: "pune", label: "Pune", state: "Maharashtra" },
  { value: "ahmedabad", label: "Ahmedabad", state: "Gujarat" },
  
  // Tier 1 Cities
  { value: "surat", label: "Surat", state: "Gujarat" },
  { value: "jaipur", label: "Jaipur", state: "Rajasthan" },
  { value: "lucknow", label: "Lucknow", state: "Uttar Pradesh" },
  { value: "kanpur", label: "Kanpur", state: "Uttar Pradesh" },
  { value: "nagpur", label: "Nagpur", state: "Maharashtra" },
  { value: "indore", label: "Indore", state: "Madhya Pradesh" },
  { value: "thane", label: "Thane", state: "Maharashtra" },
  { value: "bhopal", label: "Bhopal", state: "Madhya Pradesh" },
  { value: "visakhapatnam", label: "Visakhapatnam", state: "Andhra Pradesh" },
  { value: "patna", label: "Patna", state: "Bihar" },
  { value: "vadodara", label: "Vadodara", state: "Gujarat" },
  { value: "ghaziabad", label: "Ghaziabad", state: "Uttar Pradesh" },
  { value: "ludhiana", label: "Ludhiana", state: "Punjab" },
  { value: "agra", label: "Agra", state: "Uttar Pradesh" },
  { value: "nashik", label: "Nashik", state: "Maharashtra" },
  { value: "faridabad", label: "Faridabad", state: "Haryana" },
  { value: "meerut", label: "Meerut", state: "Uttar Pradesh" },
  { value: "rajkot", label: "Rajkot", state: "Gujarat" },
  { value: "varanasi", label: "Varanasi", state: "Uttar Pradesh" },
  { value: "srinagar", label: "Srinagar", state: "Jammu & Kashmir" },
  { value: "aurangabad", label: "Aurangabad", state: "Maharashtra" },
  { value: "dhanbad", label: "Dhanbad", state: "Jharkhand" },
  { value: "amritsar", label: "Amritsar", state: "Punjab" },
  { value: "navi-mumbai", label: "Navi Mumbai", state: "Maharashtra" },
  { value: "allahabad", label: "Allahabad", state: "Uttar Pradesh" },
  { value: "ranchi", label: "Ranchi", state: "Jharkhand" },
  { value: "howrah", label: "Howrah", state: "West Bengal" },
  { value: "coimbatore", label: "Coimbatore", state: "Tamil Nadu" },
  { value: "jabalpur", label: "Jabalpur", state: "Madhya Pradesh" },
  { value: "gwalior", label: "Gwalior", state: "Madhya Pradesh" },
  { value: "vijayawada", label: "Vijayawada", state: "Andhra Pradesh" },
  { value: "jodhpur", label: "Jodhpur", state: "Rajasthan" },
  { value: "madurai", label: "Madurai", state: "Tamil Nadu" },
  { value: "raipur", label: "Raipur", state: "Chhattisgarh" },
  { value: "kota", label: "Kota", state: "Rajasthan" },
  { value: "chandigarh", label: "Chandigarh", state: "Chandigarh" },
  { value: "gurgaon", label: "Gurgaon", state: "Haryana" },
  { value: "noida", label: "Noida", state: "Uttar Pradesh" },
  { value: "kochi", label: "Kochi", state: "Kerala" },
  { value: "mysore", label: "Mysore", state: "Karnataka" },
  { value: "thiruvananthapuram", label: "Thiruvananthapuram", state: "Kerala" },
  { value: "guwahati", label: "Guwahati", state: "Assam" },
  { value: "bhubaneswar", label: "Bhubaneswar", state: "Odisha" },
  { value: "dehradun", label: "Dehradun", state: "Uttarakhand" },
  { value: "jamshedpur", label: "Jamshedpur", state: "Jharkhand" },
];

// Gurgaon specific areas (for backward compatibility)
export const gurgaonAreas = [
  { value: "sector-45", label: "Sector 45, Gurgaon" },
  { value: "dlf-phase-5", label: "DLF Phase 5, Gurgaon" },
  { value: "cyber-city", label: "Cyber City, Gurgaon" },
  { value: "sohna-road", label: "Sohna Road, Gurgaon" },
  { value: "mg-road", label: "MG Road, Gurgaon" },
  { value: "south-city", label: "South City, Gurgaon" },
  { value: "golf-course-road", label: "Golf Course Road, Gurgaon" },
  { value: "sector-56", label: "Sector 56, Gurgaon" },
  { value: "dlf-phase-1", label: "DLF Phase 1, Gurgaon" },
  { value: "dlf-phase-2", label: "DLF Phase 2, Gurgaon" },
  { value: "dlf-phase-3", label: "DLF Phase 3, Gurgaon" },
  { value: "sector-29", label: "Sector 29, Gurgaon" },
];

// Helper function to get all locations
export function getAllLocations() {
  return [
    ...majorCities.map(city => ({ value: city.value, label: city.label })),
    ...gurgaonAreas,
  ];
}

// Helper function to group locations by state
export function getLocationsByState() {
  const grouped: Record<string, typeof majorCities> = {};
  
  majorCities.forEach(city => {
    if (!grouped[city.state]) {
      grouped[city.state] = [];
    }
    grouped[city.state].push(city);
  });
  
  return grouped;
}
